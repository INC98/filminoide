var url = "http://filmina-env.mfwayfy7uk.us-east-1.elasticbeanstalk.com";
window.addEventListener("load" ,function(){

    $(".btn-like").css("cursor","pointer");
    $(".btn-dislike").css("cursor","pointer");
    $(".btn-follow").css("cursor","pointer");
    $(".btn-unfollow").css("cursor","pointer");

    //Boton de like
    function like(){
    $(".btn-like").unbind("click").click(function(){
        console.log("like");
        $(this).addClass("btn-dislike").remove("btn-like");//Agrego una clase y le saco la otra
        $(this).attr("src",url+"/img/heart-red.png");//Cambio la imagen buscandola por url
        $.ajax({
            url: url+"/like/"+$(this).data("id"),
            type: "GET",
            success: function(response){
                if(response.like){
                    console.log("Diste like");
                }else{
                    console.log("Error al dar like");
                }
            }
        });
        dislike();        
    });
    }
    like();

    //Boton de dislike
    function dislike(){
    $(".btn-dislike").unbind("click").click(function(){
        console.log("dislike");
        $(this).addClass("btn-like").remove("btn-dislike");//Agrego una clase y le saco la otra
        $(this).attr("src",url+"/img/heart-black.png");//Cambio la imagen buscandola por url  
        $.ajax({
            url: url+"/dislike/"+$(this).data("id"),
            type: "GET",
            success: function(response){
                if(response.like){
                    console.log("Diste dislike");
                }else{
                    console.log("Error al dar dislike");
                }
            }
        });      
        like();
    });
    }
    dislike();



    //Boton de follow
    function follow(){
        $(".btn-follow").unbind("click").click(function(){
            console.log("follow");
            $(this).addClass("btn-unfollow").remove("btn-follow");//Agrego una clase y le saco la otra
            $(this).attr("src",url+"/img/popcorn-green.png");//Cambio la imagen buscandola por url
            $.ajax({
                url: url+"/follow/"+$(this).data("id"),
                type: "GET",
                success: function(response){
                    if(response.like){
                        console.log("Diste follow");
                    }else{
                        console.log("Error al dar follow");
                    }
                }
            });
            unfollow();        
        });
        }
        follow();

    //Boton de unfollow
    function unfollow(){
        $(".btn-unfollow").unbind("click").click(function(){
            console.log("unfollow");
            $(this).addClass("btn-follow").remove("btn-unfollow");//Agrego una clase y le saco la otra
            $(this).attr("src",url+"/img/popcorn-black.png");//Cambio la imagen buscandola por url  
            $.ajax({
                url: url+"/unfollow/"+$(this).data("id"),
                type: "GET",
                success: function(response){
                    if(response.like){
                        console.log("Diste unfollow");
                    }else{
                        console.log("Error al dar unfollow");
                    }
                }
            });      
            follow();
        });
        }
        unfollow();

        //Buscador
        $("#buscador").submit(function(e){
            $(this).attr("action",url+"/peliculas/"+$("#buscador #search").val());
        });
});