@if (Auth::user()->image)
<div class="container-avatar">
<img src="{{url('/user/avatar/'.Auth::user()->image)}}" alt="" class="avatar">
</div>    
@endif
{{-- Si el usuario no tiene imagen entonces le pongo una por default(no esta guardada en la bdd) --}}
@if (!Auth::user()->image)
<div class="container-avatar">
<img src="{{url('/user/avatar/'.Auth::user()->image)}}" alt="" class="avatar">
</div>    
@endif