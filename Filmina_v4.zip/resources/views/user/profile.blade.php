@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <div class="profile-user">
           
                @if($user->image)
                <div class="container-avatar">
                    <img src="{{url('/user/avatar/'.$user->image)}}" alt="" class="avatar">
                </div> 
                @endif
        
                <div class="user-info">
                    <h1>{{"@".$user->nick}}</h1>
                    <h2>{{$user->name." ".$user->surname}}</h2>
                </div>
                <div class="clearfix"></div>
                <hr>
            </div>
            <div class="clearfix"></div>
            
            <div class="card">
                
                <div class="card-header">Peliculas por ver</div>

               
                
                <div class="card-body">
                        
                    <div class="image-container1">
                       
                    <ul>
                        
                        
                        @foreach ($follows as $follow)
                        
                        <li>
                            <div class="pelicula">
                            <a href="{{route("pelicula.detail",['id'=>$follow->pelicula->id])}}">
                                <img src="{{route('pelicula.file',["filename"=>$follow->pelicula->pelicula_path])}}" alt="error">
                            </a>
                            </div>
                        </li>
                        @endforeach
                        
                    </ul>
                    
                    </div>

            </div>

            </div>
            {{-- Paginacion --}}
            <div class="clearfix links">
                {{$follows->links()}}
            </div> 
        </div>

    </div>
</div>
@endsection
