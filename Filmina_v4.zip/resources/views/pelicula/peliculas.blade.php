@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            @include('includes.message')
            <h1 class="ndeah">Buscar una pelicula</h1>
            <form action="{{route("pelicula.index")}}" method="GET" id="buscador">
                <div class="row">
                    <div class="form-group col">
                    <input type="text" id="search"  class="form-control">
                    </div>
                    <div class="form-group col btn-search">
                    <input type="submit" value="Buscar" class="btn btn-success">
                    </div>
                </div>
            </form>
            
                    <div class="image-container1">
                       
                 
                        @foreach ($peliculas as $pelicula)
                        
                        
                            <div class="pelicula">
                            <a href="{{route("pelicula.detail",['id'=>$pelicula->id])}}">
                                <img src="{{route('pelicula.file',["filename"=>$pelicula->pelicula_path])}}" alt="error">
                            </a>
                            <div class="peli-info">
                                <h1 class="ndeah">{{$pelicula->nombre}}</h1>
                            </div>
                            </div>
                            <div class="clearfix"></div>
                            <hr>
                        
                        @endforeach
                        
               
                    
                    </div>
                


            

        
            {{-- Paginacion --}}
            <div class="clearfix links">
                {{$peliculas->links()}}
            </div>
        </div>

    </div>
</div>
@endsection
