@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            @include('includes.message')
            
            <div class="card pub_pelicula pub_pelicula_detail">
                <div class="card-header">Detalle de la pelicula</div>
                
                <div class="card-body">
                    
                    <div class="containerr">
                    <div class="image-container2">    
                        <img src="{{route('pelicula.file',["filename"=>$pelicula->pelicula_path])}}" alt="error">
                    </div>
                    
                    <div class="description">
                        <h1>{{$pelicula->nombre}}</h1>
                        <p>{{$pelicula->description}}</p>
                    </div>
                    
                </div>
                    
                    <div class="likes">
                        
                        {{-- Comprobar si el usuario le dio like a la pelicula --}}
                        <?php $user_like = false; ?>  
                        @foreach ($pelicula->likes as $like)
                            @if ($like->user->id == Auth::user()->id){{--Si el id del usuario que dio like es igual al que esta conectado--}}
                            <?php $user_like = true; ?>     
                            @endif                       
                        @endforeach
                        @if ($user_like)
                    <img src="{{asset("img/heart-red.png")}}" data-id="{{$pelicula->id}}" class="btn-dislike" alt="">
                        @else
                        <img src="{{asset("img/heart-black.png")}}" data-id="{{$pelicula->id}}" class="btn-like" alt="">
                        @endif
                        <span class="number_likes">{{count($pelicula->likes)}}</span>
                        
                    </div>
                    @if (Auth::user() && Auth::user()->role == "user")
                    <div class="follow">

                         {{-- Comprobar si el usuario le dio follow a la pelicula --}}
                         <?php $user_follow = false; ?>  
                         @foreach ($pelicula->follows as $follow)
                             @if ($follow->user->id == Auth::user()->id){{--Si el id del usuario que dio follow es igual al que esta conectado--}}
                             <?php $user_follow = true; ?>     
                             @endif                       
                         @endforeach
                         @if ($user_follow)
                         <img src="{{asset("img/popcorn-green.png")}}" data-id="{{$pelicula->id}}" class="btn-unfollow" alt="">
                         @else
                        <img src="{{asset("img/popcorn-black.png")}}" data-id="{{$pelicula->id}}" class="btn-follow" alt="">
                        @endif
                        <span class="number_likes">{{count($pelicula->follows)}}</span>
                    </div>
                    @endif

                    @if (Auth::user() && Auth::user()->role == "admin")
                    <div class="actions">
                        <a href="{{route("pelicula.edit",["id"=>$pelicula->id])}}" class="btn btn-sm btn-primary">Actualizar</a>
                        {{-- <a href="{{route("pelicula.delete",["id"=>$pelicula->id])}}" class="btn btn-sm btn-danger">Borrar</a> --}}
                        <!-- Button to Open the Modal -->
                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal">
                                Eliminar
                            </button>
                            
                            <!-- The Modal -->
                            <div class="modal" id="myModal">
                                <div class="modal-dialog">
                                <div class="modal-content">
                            
                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                    <h4 class="modal-title">¿ Deseas borrar la pelicula?</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                            
                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        Si borras la pelicula no la podras recuperar
                                    </div>
                            
                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-success    " data-dismiss="modal">Cancelar</button>
                                    <a href="{{route("pelicula.delete",["id"=>$pelicula->id])}}" class="btn btn-danger">Si, borrar</a>
                                    </div>
                            
                                </div>
                                </div>
                            </div>
                    </div>    
                    @endif
                    

                    <div class="clearfix"></div>
                    <div class="comments">
                        <h2>
                            Comentarios({{count($pelicula->comments)}})
                        </h2>
                        <hr>
                        <form action="{{route("comment.save")}}" method="POST">
                            @csrf
                            <input type="hidden" name="pelicula_id" value={{$pelicula->id}}>
                            <p>
                                <textarea class="form-control {{$errors->has("content") ? "is-invalid":""}}" name="content" required cols="30" rows="5"></textarea>
                                @error('content')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first("content") }}</strong>
                                </span>
                                @enderror
                            </p>
                            <button type="submit" class="btn btn-success">Enviar</button>
                        </form>
                       <hr>
                        @foreach ($pelicula->comments as $comment)
                            <div class="comment">
                            <a href=" {{route("profile",["id" =>$comment->user->id])}} "><span class="nickname">{{"@".$comment->user->nick}}</span></a>
                                <p>{{$comment->content}}</p>
                                @if (Auth::check() &&($comment->user_id == Auth::user()->id || $comment->pelicula->user_id == Auth::user()->id)) 
                                <a href="{{route("comment.delete",["id"=>$comment->id])}}" class="btn btn-sm btn-danger">Eliminar</a>
                                @endif
                            </div>
                            <hr>
                        @endforeach

                    </div>

                </div>


            </div>

        </div>
    </div>
</div>
@endsection
