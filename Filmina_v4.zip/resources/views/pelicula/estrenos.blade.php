@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
            <div class="card">
                <div class="card-header">Próximas peliculas</div>
                
                <div class="card-body estrenos">
                        
                    <div class="image-container-estrenos">
                       <img src="{{asset("img/estrenos.png")}}" alt="">
                    
                    </div>
                


            </div>

            </div>
            
        </div>

    </div>
</div>
@endsection
