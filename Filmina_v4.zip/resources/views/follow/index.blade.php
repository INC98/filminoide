@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
            <div class="card">
                <div class="card-header">Peliculas Favoritas</div>
                
                <div class="card-body">
                        
                    <div class="image-container1">
                       
                    <ul>
                        @foreach ($follows as $follow)
                        
                        {{$follow->user_id}}
                        {{-- <li>
                            <div class="pelicula">
                            <a href="{{route("pelicula.detail",['id'=>$pelicula->id])}}">
                                <img src="{{route('pelicula.file',["filename"=>$pelicula->pelicula_path])}}" alt="error">
                            </a>
                            </div>
                        </li> --}}
                        @endforeach
                        
                    </ul>
                    
                    </div>
                


            </div>

            </div>
            {{-- Paginacion
            <div class="clearfix links">
                {{$peliculas->links()}}
            </div> --}}
        </div>

    </div>
</div>
@endsection
