<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Follow extends Model
{
    //Relacion muchos a uno
    public function user(){
        return $this->belongsTo("App\User","user_id");
    }

    //Relacion muchos a uno
    public function pelicula(){
        return $this->belongsTo("App\Pelicula","pelicula_id");
    }
}
