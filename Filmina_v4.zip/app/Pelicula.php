<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pelicula extends Model
{
    protected $table = "peliculas";

    //Relacion uno a muchos
    public function comments(){
        return $this->hasMany("App\Comment")->OrderBy("id","desc");
    }

    //Relacion uno a muchos
    public function likes(){
        return $this->hasMany("App\Like");
    }
    
    //Relacion muchos a uno
    public function user(){
        return $this->belongsTo("App\User","user_id");
    }

    //Relacion uno a muchos
    public function follows(){
        return $this->hasMany("App\Follow");
    }



}

