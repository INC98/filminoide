<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Pelicula;
use App\Comment;
use App\Like;
use App\Follow;

class PeliculaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function create(){
        return view("pelicula.create");
    }

    public function save(Request $request){
        //Validacion 
        $validate = $this->validate($request,[
            'description' => ['required'],
            'pelicula_path' => ['required', 'image'],
            "pelicula_nombre"=> ['required'],
        ]);   
        //Recoger datos
        $pelicula_path = $request->file("pelicula_path");
        $description = $request->input("description");
        $nombre = $request->input("pelicula_nombre");

        //Asignar valores nuevo objeto
        $user = \Auth::user();
        $pelicula = new Pelicula();
        $pelicula->user_id=$user->id;
        $pelicula->description=$description;
        $pelicula->nombre=$nombre;

        //Subir fichero
        if($pelicula_path){
            $pelicula_path_name=time().$pelicula_path->getClientOriginalName();
            Storage::disk("peliculas")->put($pelicula_path_name,File::get($pelicula_path));
            $pelicula->pelicula_path=$pelicula_path_name;
        }

        $pelicula->save();

        return redirect()->route("home")->with([
            "message" => "La pelicula se subio correctamente!"
        ]);
        
    }

    public function getPelicula($filename){
        $file = Storage::disk("peliculas")->get($filename);
        return new Response($file,200);
    }

    public function detail($id){
        $pelicula = Pelicula::find($id);
        return view("pelicula.detail",[
            "pelicula"=>$pelicula
        ]);
    }

    public function index($search = null){
        if (!empty($search)) {
            $peliculas=Pelicula::where("nombre","LIKE","%".$search."%")->OrderBy("id","desc")->paginate(5);
        }else{
        $peliculas = Pelicula::OrderBy("id","desc")->paginate(5);
        }
        return view("pelicula.peliculas",[
            "peliculas" => $peliculas  
        ]);
    }

    public function delete($id){
        $user = \Auth::user();
        $pelicula = Pelicula::find($id);
        $comments = Comment::where("pelicula_id",$id)->get();
        $likes = Like::where("pelicula_id",$id)->get();
        $follows = Follow::where("pelicula_id",$id)->get();

        if ($user && $pelicula && $pelicula->user->id == $user->id) {
            //Eliminar comentarios
            if ($comments && count($comments)>=1) {
                foreach($comments as $comment){
                    $comment->delete();
                } 
            }
            //Eliminar likes
            if ($likes && count($likes)>=1) {
                foreach($likes as $like){
                    $like->delete();
                } 
            }
            //Eliminar follows
            if ($follows && count($follows)>=1) {
                foreach($follows as $follow){
                    $follow->delete();
                } 
            }
            //Eliminar ficheros de peliculas de storage
            Storage::disk("peliculas")->delete($pelicula->pelicula_path);  
            //Eliminar registro de la pelicula
            $pelicula->delete();
            $message = array("message"=>"La imagen se borro correctamente");
        }else{
            $message = array("message"=>"La imagen no se borro");
        }

        return redirect()->route("home")->with($message);
    }

    public function edit($id){
        $user = \Auth::user();
        $pelicula = Pelicula::find($id);

        if($user && $pelicula && $pelicula->user->id == $user->id ){
            return view("pelicula.edit",[
                "pelicula" => $pelicula
            ]);
        }else{
            return redirect()->route("home");
        }
    }

    public function update(Request $request){
        //Validacion
        $validate = $this->validate($request,[
            "description" => ["required"],
            "pelicula_path" => ["image"],
            "pelicula_nombre"=> ['required'],
        ]);

        
        //Recoger los datos  
        $pelicula_id = $request->input("pelicula_id");
        $pelicula_path = $request->file("pelicula_path");
        $description = $request->input("description");
        $nombre = $request->input("pelicula_nombre");


        //Conseguir objeto image
        $pelicula = Pelicula::find($pelicula_id);
        $pelicula->description = $description;
        $pelicula->nombre=$nombre;

         //Subir la imagen
        if($pelicula_path){
            Storage::disk('peliculas')->delete($pelicula->pelicula_path);//Creo q no era necesario ponerlo
            $pelicula_path_name = time().$pelicula_path->getClientOriginalName();//Nombre de la foto
            Storage::disk("peliculas")->put($pelicula_path_name,File::get($pelicula_path));
            $pelicula->pelicula_path = $pelicula_path_name;
        }

        //Actualizar registro
        $pelicula->update();

        return redirect()->route("pelicula.detail",["id"=>$pelicula_id])
                        ->with(["message"=>"Pelicula actualizada correctamente"]);

    }

    public function estrenos(){
        return view("pelicula.estrenos");
    }
    

}
