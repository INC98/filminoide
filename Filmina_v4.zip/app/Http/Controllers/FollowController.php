<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Follow;

class FollowController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function follow($pelicula_id){
        //Recoger datos del usuario y la imagen
        $user = \Auth::user();

        //Condicion para ver si ya existe el like y no duplicarlo
        $isset_follow = Follow::where("user_id",$user->id)->where("pelicula_id",$pelicula_id)->count();
        if($isset_follow == 0){
        $follow = new Follow();
        $follow->user_id = $user->id;
        $follow->pelicula_id = (int)$pelicula_id;

        $follow->save();

        return response()->json([
            "follow" => $follow
        ]);
        }else{
            return response()->json([
                "message" => "El follow ya existe"
            ]);
        }
    }

    public function unfollow($pelicula_id){
        //Recoger datos del usuario y la imagen
        $user = \Auth::user();

        //Condicion para ver si ya existe el like y no duplicarlo
        $follow = Follow::where("user_id",$user->id)->where("pelicula_id",$pelicula_id)->first();
        if($follow){
            //Eliminar
            $follow->delete();

        return response()->json([
            "follow" => $follow,
            "message" => "Has dado unfollow"
        ]);
        }else{
            return response()->json([
                "message" => "El follow no existe"
            ]);
        }
    }


}
