<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\User;
use App\Follow;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function config(){
        return view("user.config");
    }

    public function update(Request $request){
        //Conseguir usuario identificado
        $user = \Auth::user();
        $id = $user->id;
        //Validacion del formulario
        $validate = $this->validate($request,[
            'name' => ['required', 'string', 'max:255'],
            'surname' => ['required', 'string', 'max:255'],
            'nick' => ['required', 'string', 'max:255', 'unique:users,nick,'.$id],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$id],
        ]);
        //Recoger los datos del formulario
        $name = $request->input("name");
        $surname = $request->input("surname");
        $nick = $request->input("nick");
        $email = $request->input("email");
        //Asignar nuevos valores al objeto usuario
        $user->name = $name;
        $user->surname = $surname;
        $user->nick = $nick;
        $user->email = $email;
        //Subir la imagen
        $image_path = $request->file("image_path");
        if($image_path){
            $image_path_name = time().$image_path->getClientOriginalName();//Nombre de la imagen
            Storage::disk("users")->put($image_path_name,File::get($image_path));//Guarda la imagen en el storage de users
            $user->image=$image_path_name;//Seteo nombre de la imagen
        }
        //Ejecutar consulta y cambios en la bdd
        $user->update();
        return redirect()->route("config")
                        ->with(["message"=>"Usuario actualizado correctamente"]);
    }

    public function getImage($filename){
        $file = Storage::disk("users")->get($filename);
        return new Response($file,200);
    }

    public function profile($id){
        $user = User::find($id);
        $follows = Follow::where("user_id",$user->id)->orderBy("id","desc")->paginate(12);
        return view("user.profile",[
            "user" => $user,
            "follows" => $follows
        ]);

    }


    
}
