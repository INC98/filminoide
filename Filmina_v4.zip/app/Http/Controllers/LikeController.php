<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Like;

class LikeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function like($pelicula_id){
        //Recoger datos del usuario y la imagen
        $user = \Auth::user();

        //Condicion para ver si ya existe el like y no duplicarlo
        $isset_like = Like::where("user_id",$user->id)->where("pelicula_id",$pelicula_id)->count();
        if($isset_like == 0){
        $like = new Like();
        $like->user_id = $user->id;
        $like->pelicula_id = (int)$pelicula_id;

        $like->save();

        return response()->json([
            "like" => $like
        ]);
        }else{
            return response()->json([
                "message" => "El like ya existe"
            ]);
        }
    }

    public function dislike($pelicula_id){
        //Recoger datos del usuario y la imagen
        $user = \Auth::user();

        //Condicion para ver si ya existe el like y no duplicarlo
        $like = Like::where("user_id",$user->id)->where("pelicula_id",$pelicula_id)->first();
        if($like){
            //Eliminar
            $like->delete();

        return response()->json([
            "like" => $like,
            "message" => "Has dado dislike"
        ]);
        }else{
            return response()->json([
                "message" => "El like no existe"
            ]);
        }
    }

}
