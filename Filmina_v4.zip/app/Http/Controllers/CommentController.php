<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comment;

class CommentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function save(Request $request){

        //Validacion
        $validate =  $this->validate($request,[
            "pelicula_id" =>["int","required"],
            "content" => ["string","required"]
        ]);

        //Recoger datos
        $user = \Auth::user();
        $pelicula_id=$request->input("pelicula_id");
        $content = $request->input("content");

        //Asigno los valores a mi nuevo objeto a guardar
        $comment = new Comment();
        $comment->user_id = $user->id;
        $comment->pelicula_id = $pelicula_id;
        $comment->content=$content;

        //Guardar en bdd
        $comment->save();
        
        //Redireccion
        return redirect()->route("pelicula.detail",["id"=>$pelicula_id])->with(["message" => "Has realizado un comentario"]);

    }

    public function delete($id){
        //Conseguir datos del usuario identificado
        $user = \Auth::user();

        //Conseguir objeto del comentario
        $comment = Comment::find($id);

        //Comprobar si soy el dueño del comentario o de la publicacion
        if ($user &&($comment->user_id == $user->id || $comment->pelicula->user_id == $user->id)) {
            $comment->delete();
            return redirect()->route("pelicula.detail",["id"=>$comment->pelicula->id])->with(["message" => "Comentario eliminado correctamente"]);
        }else {
            return redirect()->route("pelicula.detail",["id"=>$comment->pelicula->id])->with(["message" => "El comentario no se ha eliminado"]);
        }
    }
    
}
