<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//use App\Follow;

Route::get('/', function () {
    //CREO QUE PUEDE SERVIR(muestra todos los follows de las series)
    // $follows = Follow::all();

    // foreach($follows as $follow){
    //     echo "<pre>";
    //     var_dump($follow->serie);
    //     echo "</pre>";
    // }

    //die();
    return view('welcome');
});

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get("/configuracion","UserController@config")->name("config");
Route::post("/user/update","UserController@update")->name("user.update");
Route::get("/user/avatar/{filename}","UserController@getImage")->name("user.avatar");
Route::get("/subir-pelicula","PeliculaController@create")->name("pelicula.create");
Route::post("/pelicula/save","PeliculaController@save")->name("pelicula.save");
Route::get("/pelicula/file/{filename}","PeliculaController@getPelicula")->name("pelicula.file");
Route::get("/pelicula/{id}","PeliculaController@detail")->name("pelicula.detail");
Route::post("/comment/save","CommentController@save")->name("comment.save");
Route::get("/comment/delete/{id}","CommentController@delete")->name("comment.delete");
Route::get("/like/{pelicula_id}","LikeController@like")->name("like.save");
Route::get("/dislike/{pelicula_id}","LikeController@dislike")->name("like.delete");
Route::get("/follow/{pelicula_id}","FollowController@follow")->name("follow.save");
Route::get("/unfollow/{pelicula_id}","FollowController@unfollow")->name("follow.delete");
Route::get("/perfil/{id}","UserController@profile")->name("profile");
Route::get("/peliculas/{search?}","PeliculaController@index")->name("pelicula.index");
Route::get("/pelicula/delete/{id}","PeliculaController@delete")->name("pelicula.delete");
Route::get("/pelicula/editar/{id}","PeliculaController@edit")->name("pelicula.edit");
Route::post("/pelicula/update","PeliculaController@update")->name("pelicula.update");
Route::get("/estrenos","PeliculaController@estrenos")->name("pelicula.estrenos");