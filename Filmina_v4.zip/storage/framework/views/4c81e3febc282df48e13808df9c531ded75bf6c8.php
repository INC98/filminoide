<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="card">
                <div class="card-header">Peliculas disponibles</div>
                
                <div class="card-body">
                        
                    <div class="image-container1">
                       
                    <ul>
                        <?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li>
                            <div class="pelicula">
                            <a href="<?php echo e(route("pelicula.detail",['id'=>$pelicula->id])); ?>">
                                <img src="<?php echo e(route('pelicula.file',["filename"=>$pelicula->pelicula_path])); ?>" alt="error">
                            </a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                    
                    </div>
                


            </div>

            </div>
            
            <div class="clearfix links">
                <?php echo e($peliculas->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Filmina\resources\views/home.blade.php ENDPATH**/ ?>