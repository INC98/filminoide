<li>
        <div class="pelicula">
        <a href="<?php echo e(route("pelicula.detail",['id'=>$pelicula->id])); ?>">
            <img src="<?php echo e(route('pelicula.file',["filename"=>$pelicula->pelicula_path])); ?>" alt="error">
        </a>
        </div>
    </li><?php /**PATH C:\xampp\htdocs\pruebas-laravel\peliculas\resources\views/includes/pelicula.blade.php ENDPATH**/ ?>