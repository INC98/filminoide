<?php if(session("message")): ?>
<div class="alert alert-success">
    <?php echo e(session("message")); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Filmina\resources\views/includes/message.blade.php ENDPATH**/ ?>