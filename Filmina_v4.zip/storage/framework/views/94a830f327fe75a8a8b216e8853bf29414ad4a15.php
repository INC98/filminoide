<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <div class="profile-user">
           
                <?php if($user->image): ?>
                <div class="container-avatar">
                    <img src="<?php echo e(url('/user/avatar/'.$user->image)); ?>" alt="" class="avatar">
                </div> 
                <?php endif; ?>
        
                <div class="user-info">
                    <h1><?php echo e("@".$user->nick); ?></h1>
                    <h2><?php echo e($user->name." ".$user->surname); ?></h2>
                </div>
                <div class="clearfix"></div>
                <hr>
            </div>
            <div class="clearfix"></div>
            
            <div class="card">
                
                <div class="card-header">Peliculas por ver</div>

               
                
                <div class="card-body">
                        
                    <div class="image-container1">
                       
                    <ul>
                        
                        
                        <?php $__currentLoopData = $follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li>
                            <div class="pelicula">
                            <a href="<?php echo e(route("pelicula.detail",['id'=>$follow->pelicula->id])); ?>">
                                <img src="<?php echo e(route('pelicula.file',["filename"=>$follow->pelicula->pelicula_path])); ?>" alt="error">
                            </a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                    
                    </div>

            </div>

            </div>
            
            <div class="clearfix links">
                <?php echo e($follows->links()); ?>

            </div> 
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebas-laravel\peliculas\resources\views/user/profile.blade.php ENDPATH**/ ?>