<?php if(Auth::user()->image): ?>
<div class="container-avatar">
<img src="<?php echo e(url('/user/avatar/'.Auth::user()->image)); ?>" alt="" class="avatar">
</div>    
<?php endif; ?>

<?php if(!Auth::user()->image): ?>
<div class="container-avatar">
<img src="<?php echo e(url('/user/avatar/'.Auth::user()->image)); ?>" alt="" class="avatar">
</div>    
<?php endif; ?><?php /**PATH C:\xampp\htdocs\pruebas-laravel\peliculas\resources\views/includes/avatar.blade.php ENDPATH**/ ?>