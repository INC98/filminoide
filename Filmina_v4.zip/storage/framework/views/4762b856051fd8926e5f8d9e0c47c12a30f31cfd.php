<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
            <div class="card">
                <div class="card-header">Próximas peliculas</div>
                
                <div class="card-body estrenos">
                        
                    <div class="image-container-estrenos">
                       <img src="<?php echo e(asset("img/estrenos.png")); ?>" alt="">
                    
                    </div>
                


            </div>

            </div>
            
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Filmina\resources\views/pelicula/estrenos.blade.php ENDPATH**/ ?>