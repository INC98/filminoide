<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h1 class="ndeah">Buscar una pelicula</h1>
            <form action="<?php echo e(route("pelicula.index")); ?>" method="GET" id="buscador">
                <div class="row">
                    <div class="form-group col">
                    <input type="text" id="search"  class="form-control">
                    </div>
                    <div class="form-group col btn-search">
                    <input type="submit" value="Buscar" class="btn btn-success">
                    </div>
                </div>
            </form>
            
                    <div class="image-container1">
                       
                 
                        <?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                            <div class="pelicula">
                            <a href="<?php echo e(route("pelicula.detail",['id'=>$pelicula->id])); ?>">
                                <img src="<?php echo e(route('pelicula.file',["filename"=>$pelicula->pelicula_path])); ?>" alt="error">
                            </a>
                            <div class="peli-info">
                                <h1 class="ndeah"><?php echo e($pelicula->nombre); ?></h1>
                            </div>
                            </div>
                            <div class="clearfix"></div>
                            <hr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
               
                    
                    </div>
                


            

        
            
            <div class="clearfix links">
                <?php echo e($peliculas->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebas-laravel\peliculas\resources\views/pelicula/peliculas.blade.php ENDPATH**/ ?>