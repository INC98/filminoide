<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Subir nueva pelicula</div>
            
            <div class="card-body">
                <form action="<?php echo e(route("pelicula.save")); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group row">
                        <label for="pelicula_path" class="col-md-3 col-form-label text-md-right">Pelicula</label>
                        <div class="col-md-7">
                            <input id="pelicula_path" type="file" name="pelicula_path" class="form-control <?php echo e($errors->has("pelicula_path") ? "is-invalid":""); ?>" required>   
                            <?php if ($errors->has('pelicula_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pelicula_path'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                        </div> 
                    </div>

                    <div class="form-group row">
                        <label for="pelicula_nombre" class="col-md-3 col-form-label text-md-right">Nombre</label>
                        <div class="col-md-7">
                            <input id="pelicula_nombre" type="text" name="pelicula_nombre" class="form-control <?php echo e($errors->has("pelicula_nombre") ? "is-invalid":""); ?>" required>   
                            <?php if ($errors->has('pelicula_nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pelicula_nombre'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                        </div> 
                    </div>

                    <div class="form-group row">
                            <label for="description" class="col-md-3 col-form-label text-md-right">Descripcion</label>
                            <div class="col-md-7">
                            <textarea id="description" name="description" class="form-control <?php echo e($errors->has("description") ? "is-invalid":""); ?>" required></textarea>   
                            <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                        </div> 
                    </div>




                    <div class="form-group row">
                        <div class="col-md-6 offset-md-3">
                            <input type="submit" class="btn btn-primary" value="Subir Pelicula">   
                        </div> 
                    </div>
                        
                </form>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Filmina\resources\views/pelicula/create.blade.php ENDPATH**/ ?>