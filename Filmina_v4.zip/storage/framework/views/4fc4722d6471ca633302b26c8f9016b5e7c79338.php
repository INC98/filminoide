<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
            <div class="card">
                <div class="card-header">Peliculas Favoritas</div>
                
                <div class="card-body">
                        
                    <div class="image-container1">
                       
                    <ul>
                        <?php $__currentLoopData = $follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php echo e($follow->user_id); ?>

                            <?php echo $__env->make("includes.pelicula",["pelicula" => $follow->pelicula], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                    
                    </div>
                


            </div>

            </div>
            
            <div class="clearfix links">
                <?php echo e($follows->links()); ?>

            </div> 
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebas-laravel\peliculas\resources\views/follow/index.blade.php ENDPATH**/ ?>